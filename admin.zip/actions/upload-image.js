const path = require('path');
const fs = require('fs');
const AdminBro = require('admin-bro');
const {ValidationError} = require('admin-bro');

/** @type {AdminBro.After<AdminBro.ActionResponse>} */
const after = async (response, request, context) => {
  const { record, image } = context;

//   if (record.isValid() && image) {
//     const filePath = path.join('uploads', image.name);
//     await fs.promises.mkdir(path.dirname(filePath), { recursive: true });

//     await fs.promises.rename(image.path, filePath);

//     // record.params.image = `/${filePath}`;
//     await record.update({ image: `/${filePath}` });
//   }
  return response;
};

/** @type {AdminBro.Before} */
const before = async (request, context) => {
  if (request.method === 'post') {
    const { image, ...otherParams } = request.payload;
    
    if (image == undefined) {
      throw new ValidationError({
        name: {
          message: 'Alert',
        },
      }, {
        message: 'Image is Required',
      })
    }

    console.log(image);

    if (typeof image === 'string' || image instanceof String) {

    }else {
          const filePath = path.join('uploads', Math.floor(Math.random() * 20000000).toString(), image.name);
          await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
      
          await fs.promises.rename(image.path, filePath);
          // eslint-disable-next-line no-param-reassign
          context.image = `/${filePath}`;
          request.payload.image = `/${filePath}`;

    }

    return request;
    }
    return request;
};

module.exports = { after, before };
